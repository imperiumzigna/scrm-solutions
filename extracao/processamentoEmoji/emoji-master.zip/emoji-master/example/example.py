# -*- coding: UTF-8 -*-
import emoji

print(emoji.emojize('Water! :water_wave:'))
print(emoji.demojize(u'🌊')) # for Python 2.x
# print(emoji.demojize('🌊')) # for Python 3.x
